#include "Questao3Header.h"
#include <stdio.h>

int main()
{
    alocar_memoria();
    return 0;
}